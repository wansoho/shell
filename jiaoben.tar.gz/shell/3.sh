#!/bin/bash



select_game()
{

    GAMENAME= (rxsg2 rxsg wtby mssg);
   
   case $GAMENAME in
      1)
         platid='rxsg2'
           ;;
      2)
         platid='rxsg'
           ;;
      3)
         platid='wtby'
           ;;
      4)
         platid='mssg'
           ;;
      *)
           ;;
    esac
      
  echo "1) 热血三国2"
  echo "2) 热血三国"
echo "请选择游戏: "
}
