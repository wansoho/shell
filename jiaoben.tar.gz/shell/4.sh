#!/bin/bash

for i in `cat f.txt`
do
 echo -e "\033[44;37;5m ME\033[0m $i"
done
