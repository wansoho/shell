#!/bin/bash


print_usage(){
         printf "Please enter an integer \n"
         exit 1
}

read -p "Please input first number: " firstnum

if [ -n "`echo $firstnum|sed 's/[0-9]//g'|sed 's/-//g'`"];then
   echo "0" >>/dev/null &  
   else
   print_usage
fi

read -p "Please input the operators: " operators

if [ "${operators}" != "+" ]&&[ "${operators}" != "-" ]&&[ "${operators}" != "*" ]&&[ "${operators}" != "/" ]&&[ "${operators}" != "**" ]&&[ "${operators}" != "%" ];then
  
   echo "please use + - * / ** %"
   exit 1
fi

read -p "Please input second number: " secondnum

if [ -n "`echo $secondnum|sed 's/[0-9]//g'|sed 's/-//g'`"];then

   echo "0" >>/dev/null &  
   else  
   print_usage
fi

echo "${firstnum}${operators}${secondnum}=$((${firstnum}${operators}${secondnum}))"
