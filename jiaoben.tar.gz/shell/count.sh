#!/bin/bash

H=$1
user=binuser
passwd=sg2binuser

Ths=`mysqladmin status|awk '{print $4}'`

if [ $Ths -lg 1000 ];then
 
    echo "mysql Threads too many" >>/dev/null
  
fi


 
