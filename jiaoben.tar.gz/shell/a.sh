dirname  $0
basename  $0
