#!/bin/bash
. ./db_port.lst


##################
function if_error
##################
{
erron=$?
if [ $erron -ne 0 ]; then # check return code passed to function
    echo "error $1, code $erron" >&2
    exit $erron
fi
}
if [ "$1" == "" ]; then
    i=1
else
    i=$1
fi


if [ "$2" == "" ]; then
    j=${#servers[*]}
else
    j=$2
fi

k=$i
m=$((j+1))
echo backup db [$i] ${servers[$i]} - [$j] ${servers[$j]}

while [ $i -lt $m ]; do
    addr=${servers[$i]%%:*}
    if [ `expr index ${servers[$i]} ':'` -ne 0 ]; then
        port=${servers[$i]##*:}
    else
        if_error $i
    fi
    echo "-----------Servers [${k} ~ ${j}] NOW ${i} [root@${addr} : ${port}]---------"
    scp huidang.sh root@${addr}:/backup
    ssh root@${addr} "/backup/huidang.sh rxsg2 ${port} &" &
    i=$((i+1))
done
