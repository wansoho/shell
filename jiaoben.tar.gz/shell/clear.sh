#!/bin/bash
cd /data/
port=`ls`
for i in `$port`
do
cd /data/$port
ls core.*
if [ $? -eq 0 ] 
then
  rm -vf core.*
#else
#  exit
fi
done
