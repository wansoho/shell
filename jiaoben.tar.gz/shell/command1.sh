while echo "please choose:"
do
select vi in "hostname" "ifconfig" "hosts" "quit"
do 
case $vi in
"hostname") hostname ;;
"ifconfig") ifconfig ;;
"hosts") more /etc/hosts ;;
"quit") exit ;;
*) continue ;;
esac


break
done
done
