#!/bin/bash

. ./bin_server.lst


##################
function if_error
##################
{
erron=$?
if [ $erron -ne 0 ]; then # check return code passed to function
    echo "error $1, code $erron" >&2
    exit $erron
fi
}

if [ "$1" == "" ]; then
    echo no version
    exit
else
    version=$1
fi

if [ "$2" == "" ]; then
    i=1
else
    i=$2
fi


if [ "$3" == "" ]; then
    j=${#servers[*]}
else
    j=$3
fi

k=$i
m=$((j+1))
echo copy server [$i] ${servers[$i]} - [$j] ${servers[$j]}

while [ $i -lt $m ]; do
    addr=${servers[$i]%%:*}
    echo "-----------Servers [${k} ~ ${j}] NOW ${i} [root@${addr}]---------"
        ssh root@${addr} "ps aux|grep rxsg2_s*">>2.txt
        echo ------------Servers [${k} ~ ${j}] Server[$i] OK-------------
    i=$((i+1))
done
