#!/bin/bash

rxsg2_qianyi()
{
> id_list    #shell遇到”>”操作符，会判断右边文件是否存在，如果存在就先删除，并且创建新文件。不存在直接创建。 无论左边命令执行是否成功。右边文件都会变为空。
echo "please input ali_bin_ip "
read ali_bin_ip
echo "please input (平台)partner_id "
read partner_id
echo "please input game_id "
read game_id
echo "please input idc_id "
read idc_id
mysql -ubinuser -psg2binuser -h183.60.46.72 dist -Nse "select server_id,web_server from server where mod_server=0 and state=1 and partner_id=${partner_id} and game_id=${game_id} and idc_room_id=${idc_id}" >> id_list

while read line
do
     SERVER_ID=`echo $line  | awk '{print $1}'`
     WEB_SERVER=`echo $line |awk '{print $2}'| awk -F'/' '{print $1}'`
     ssh   ${WEB_SERVER}   "rsync -avuz /rxsg2/bin/s${SERVER_ID} ${ali_bin_ip}::rxsg2" &
     ssh ${ali_bin_ip}   "echo '##* * * * * /rxsg2/bin/s${SERVER_ID}/start_server.sh s${SERVER_ID} &' >> /var/spool/cron/root"  &
     echo  "已添加cron  s${SERVER_ID}"
done

}

rxsg2_qianyi;
