#!/bin/bash
clear
echo '~~~~~~请选择跨服~~~~~~~';
#cd /rxsg2/ver
BRKF=/data1/rxsg2/bin/brkf      #皇陵探宝
WSKF=/data/rxsg2/bin/kf1        #天下无双跨服
MZKF=/data/rxsg2/bin_mzkf/mzkf  #雄霸天下
update_brkf()
{
    version=$1
    scp -r br_${version} brkf:/rxsg2/ver
    ssh root@brkf "tar -zxf /rxsg2/ver/br_${version}/*_br.tar.gz -C /rxsg2/ver/br_${version}"
    ssh root@brkf "ln -sf /rxsg2/ver/br_${version}/bin/BRServer.bin  $BRKF"
}

update_wskf()
{
    version=$1
    scp -r kf_${version} wskf:/rxsg2/ver
    ssh root@wskf "tar -zxf /rxsg2/ver/kf_${version}/*_kf.tar.gz -C /rxsg2/ver/kf_${version}"
    ssh root@wskf "ln -sf /rxsg2/ver/kf_${version}/bin/KuaFuServer.bin  $WSKF"
}
update_mzkf()
{  
    version=$1
    scp -r mzkf_${version} mzkf:/rxsg2/ver
    ssh root@mzkf "tar -zxf /rxsg2/ver/mzkf_${version}/*_mzkf.tar.gz -C /rxsg2/ver/mzkf_${version}"
    ssh root@mzkf "ln -sf /rxsg2/ver/mhkf_${version}/bin/KFMZServer.bin  $MZKF"
}
#select_kf()
#{   
#		PS3="Select an choice: "
#	    select option in  "-- [皇陵探宝]  " "-- [天下无双]  " "-- [雄霸天下]  " "-- [EXIT]  "
#         do   
#            case $REPLY in
#         1)
#                  kf='brkf';
#             host='brkf';
#             break;
#             ;;
#         2)
#                  kf='wskf';
#             host='wskf';
#             break;
#             ;;
#         3)
#                  kf='mzkf';
#             host='mzkf';
#             break;
#             ;;
#         *)
#                exit
#             ;;
#         esac
#        done 
#}
update_bin()
{
    while [ 1 ]
    do
          echo
          echo "##### 1) \033[41;37m update_wskf \033[0m"
          echo "##### 2)  update_mzkf"
          echo "##### 3)  update_brkf"
          echo "##### 4)  break"
          echo
          read -p "what do you want to udpate :" choose
          case $choose in
              1)
              read -p "# wskf version :" a
              update_wskf $a;
              continue;
              ;;
              2)
              read -p "# mzkf version :" b
              update_mzkf $b;
              continue;
              ;;
              3)
              read -p "# brkf version :" c
              update_brkf $c;
              continue;
              ;; 
              4)
              break;
              ;;
          esac
      done
 }
update_bin
