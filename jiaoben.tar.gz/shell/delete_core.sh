#!/bin/bash
cd /$1/bin

delete_core()
{
    for i in `ls`
    do
    echo $i
    cd /$1/bin/$i
    ls core.*
    if [ $? -eq 0 ];then
    find /$1/bin -maxdepth 2 -type f -name "core.*" -ctime +3 -exec rm -f {} \;
    echo `date +%Y%m%d--%T`>>/opt/core
    for co in `ls -t core.*|tail -n +2`
    do
    echo `pwd` >>/opt/core
    rm -vf $co;echo `date +%Y%m%d--%T`>>/opt/core
    done
   fi  
done
}
delete_core
