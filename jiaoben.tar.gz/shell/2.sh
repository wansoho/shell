#!/bin/bash


int=2

while (( $int <= 3 ))
do
echo $int
let "int--"
   if [ $int -lt 1 ];then
   sleep 1;
#   let "int--"
fi
done
