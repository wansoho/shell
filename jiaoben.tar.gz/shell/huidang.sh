#!/bin/bash

# $1为游戏简称，例如：rxsg2
# $2为游戏服ID  例如：10123


DATE_C=`date +%Y%m%d`
DATE=`date +%Y.%m.%d.%H.%M.%S`
MYSQLDIR=/usr/local/mysql/bin
MYSQLCMD="${MYSQLDIR}/mysql -ubinuser -psg2binuser -h10.140.46.72"
MYSQLBAK="${MYSQLDIR}/mysqldump -urxsg2 -prxsg2_backuper"
local_IP=`/sbin/ifconfig | awk '{if(match($0,/[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+/)) print substr($0,RSTART,RLENGTH);}'|head -1`

#建备份状态表
create_table()
   {
        ${MYSQLCMD} -D bak_check -e "CREATE TABLE IF NOT EXISTS backup_${1} (
          game_id int(10) NOT NULL COMMENT '游戏服ID',
          server_id int(10) NOT NULL COMMENT '游戏服序号',
          db_name char(20) NOT NULL COMMENT '数据库名称',
          IDC_ROOM int(10) NOT NULL COMMENT '机房ID',
          back_mark int(10) NOT NULL COMMENT '备份标记',
          PRIMARY KEY  (server_id)
          )ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='备份检查管理' ;"
   }


create_table ${DATE_C};

if [ $# -eq 2 ];then
     mkdir -p /backup/db
     cd /backup/db
     ${MYSQLBAK} ${1}_$2 > ${1}_${2}_${DATE}.sql 2> /backup/db/db.err
     /bin/gzip -f ${1}_${2}_${DATE}.sql 


elif [ $# -eq 1 ];then
     mkdir -p /backup/db
     cd /backup/db

     #游戏名称
     GAME_NAME=`${MYSQLCMD} -D dist -N -e "select cn_name from game where en_name='$1'"`
     echo $GAME_NAME;

     #游戏ID
     GAME_ID=`${MYSQLCMD} -D dist -N -e "select game_id from game where en_name='$1'"`
     echo  ${GAME_ID};

     # 服务器上ID列表
     id_list=`${MYSQLCMD} -D dist -N -e "select server_id from server where game_id='${GAME_ID}' and db_server='${local_IP}' and mod_server=0 and state=1"`;

     for i in `echo ${id_list}`;do 
        port_ID=`${MYSQLCMD} -D dist -N -e "select server_id from server where game_id='${GAME_ID}' and db_server='${local_IP}' and mod_server=0 and server_id='${i}'"`
        ${MYSQLBAK} ${1}_s${port_ID} >  ${1}_s${port_ID}_${DATE}.sql;
        STATE=$?
        /bin/gzip -f ${1}_s${port_ID}_${DATE}.sql;

        #机房ID
        IDC_ROOM=`${MYSQLCMD} -D dist -N -e "select idc_room_id from server where server_id='$i'"`

        ${MYSQLCMD} -D bak_check -N -e "delete from backup_${DATE_C} where server_id='${i}';insert into backup_${DATE_C} values('${GAME_ID}','${i}','${1}_s${port_ID}','${IDC_ROOM}',"${STATE}");"
     done

else
    echo "请输入参数,例如"
    echo "全部备份：/backup/backupdb.sh rxsg2"
    echo "备份单个游戏服：/backup/backupdb.sh mjhx3 s9360"

fi
