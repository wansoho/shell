#!/usr/bin/python2.7
# coding:utf-8
# author: the5fire
import urllib2
url = 'http://www.taobao.com'
content = urllib2.urlopen(url).read()
print content.decode('utf-8')
